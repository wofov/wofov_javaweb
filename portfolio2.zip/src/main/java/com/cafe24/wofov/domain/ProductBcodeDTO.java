package com.cafe24.wofov.domain;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ProductBcodeDTO {
	private String bcode;
}
